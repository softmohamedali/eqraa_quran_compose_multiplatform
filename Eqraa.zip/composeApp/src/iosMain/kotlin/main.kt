import androidx.compose.ui.window.ComposeUIViewController
import com.moali.eqraa.App
import platform.UIKit.UIViewController

fun MainViewController(): UIViewController {
    return ComposeUIViewController { App() }
}
