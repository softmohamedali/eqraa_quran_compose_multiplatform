import com.moali.eqraa.App
import org.jetbrains.skiko.wasm.onWasmReady

fun main() {
    onWasmReady {
        BrowserViewportWindow("Eqraa") {
            App()
        }
    }
}
